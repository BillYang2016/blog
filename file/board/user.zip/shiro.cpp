#ifdef LEMON_JUDGE
#include "../../data/board/grader.cpp"
#include "../../source/your_name/sora.cpp"
//Please relpace "your_name" with your id.
//It should not contain spaces or chinese characters.
#else
#include "grader.h"
#endif
using namespace std;
//Do not declare any global variables
namespace shiro{
	//declare your variables here

	//implement these functions
	void initShiro(int caseno){}

	void shiro(int x, int y){
		for (int i=0; i<N; i++)
			for (int j=0; j<N; j++)
				setFlag(i, j, i==x && j==y);
	}
}