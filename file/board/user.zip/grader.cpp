#include <iostream>
#include <cstdio>
#include <algorithm>
#include <string>
#include <cstdlib>
#include <cstring>
#include "grader.h"
using namespace std;
namespace shiro{
	void initShiro(int caseno);
	void shiro(int x, int y);
}
namespace sora{
	void initSora(int caseno);
	void sora(int x, int y, std::vector<int> v);
}
int grid[N][N];
int fcnt, mcnt, ans;
#define abs(x) ((x)>=0?(x):(-(x)))

void judge(string info){
	cerr << info << endl;
	exit(0);
}

string to_string(int x, int y){
	return "("+to_string(x)+","+to_string(y)+")";
}

int position(int x, int y){
	if (x < 0 || x >= N || y < 0 || y >= N)
		return -1;
	if (x==0 || x==N-1 || y==0 || y==N-1)
		return 0;
	return 1;
}

void setFlag(int x, int y, int val){
	fcnt++;
	if (fcnt > N*N)
		judge("Too many setFlags!");
	if (position(x, y) == -1)
		judge("Invalid setFlag operation: "+to_string(x, y)+".");
	grid[x][y] = val;
}

int curx, cury, scnt;
int sx, sy, ex, ey;
bool suc;

std::vector<int> move(int dir, int count){
	if (count >= N)
		judge("Move too far!");
	if (count <= 0)
		judge("Invalid argument!");
	if (dir < 0 || dir >= 4)
		judge("Invalid direction!");
	curx += dx[dir]*count;
	cury += dy[dir]*count;
	if (position(curx, cury) <= 0)
		judge("Move out of bounds!");
	mcnt += count;
	scnt++;
	if (mcnt > ans)
		judge("Your path is not optimal!");
	vector<int> ret;
	if (curx == ex && cury == ey){
		suc = true;
		return ret;
	}
	for (int i=0; i<=4; i++){
		int nx = curx+dx[i];
		int ny = cury+dy[i];
		ret.push_back(grid[nx][ny]);
	}
	return ret;
}

int main(){
	freopen("board.in", "r", stdin);
	shiro::initShiro(1);
	sora::initSora(1);
	while (cin >> sx >> sy >> ex >> ey){
		fcnt = mcnt = scnt = 0;
		suc = false;
		curx = sx;
		cury = sy;
		ans = abs(sx-ex) + abs(sy-ey);
		shiro::shiro(ex, ey);
		printf("setFlag succeeded: %d operations.\n", fcnt);
		vector<int> ret;
		for (int i=0; i<=4; i++){
			int nx = sx+dx[i];
			int ny = sy+dy[i];
			ret.push_back(grid[nx][ny]);
		}
		sora::sora(sx, sy, ret);
		if (suc)
			printf("Correct: %d steps.\n", scnt);
		else
			printf("You did not reach the destination!");
	}
	return 0;
}
