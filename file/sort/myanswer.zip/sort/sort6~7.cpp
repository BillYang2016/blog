#include<algorithm>
#include<iostream>
#include<iomanip>
#include<cstring>
#include<cstdlib>
#include<climits>
#include<vector>
#include<cstdio>
#include<cmath>
#include<queue>
using namespace std;

inline const int Get_Int() {
	int num=0,bj=1;
	char x=getchar();
	while(x<'0'||x>'9') {
		if(x=='-')bj=-1;
		x=getchar();
	}
	while(x>='0'&&x<='9') {
		num=num*10+x-'0';
		x=getchar();
	}
	return num*bj;
}

int n,m,pos[1005],id[1005],Now;
vector<int> ans;

int main() {
	freopen("sort7.in","r",stdin);
	freopen("sort7.out","w",stdout);
	n=Get_Int();
	m=Get_Int();
	for(int i=1; i<=n; i++) {
		int x=Get_Int();
		pos[x]=i;
		if(x==1)Now=i;
	}
	for(int i=1; i<=m; i++) {
		Get_Int();
		Get_Int();
		id[Get_Int()]=i;
	}
	while(Now!=1) {
		ans.push_back(id[Now]);
		swap(Now,pos[Now]);
	}
	while(true) {
		pos[1]=1;
		bool bj=0;
		for(int i=1; i<=n; i++)
			if(pos[i]!=i) {
				bj=1;
				Now=pos[i];
				ans.push_back(id[i]);
				swap(pos[i],pos[1]);
				break;
			}
		if(!bj)break;
		while(Now!=1) {
			ans.push_back(id[Now]);
			swap(Now,pos[Now]);
		}
	}
	printf("%d\n",ans.size());
	for(int x:ans)printf("%d\n",x);
	return 0;
} 

