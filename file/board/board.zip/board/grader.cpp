#include <iostream>
#include <cstdio>
#include <algorithm>
#include <string>
#include <cstdlib>
#include <cstring>
#include "grader.h"
#define PROC "board"
using namespace std;
namespace shiro{
	void initShiro(int caseno);
	void shiro(int x, int y);
}
namespace sora{
	void initSora(int caseno);
	void sora(int x, int y, std::vector<int> v);
}
namespace grader{
	enum result {
		CORRECT,
		TOO_MANY_STEPS,
		TOO_MANY_FLAGS,
		SETFLAG_INVALID_ARGUMENT,
		SETFLAG_OUT,
		MOVE_INVALID_ARGUMENT,
		MOVE_TOO_FAR,
		MOVE_OUT,
		MOVE_NOT_OPTIMAL,
		UNEXPECTED_TERMINATION
	};

	struct judgeData{
		int sx, sy, ex, ey;
		int save[N][N];
		bool read(){
			bool ret(cin >> sx >> sy >> ex >> ey);
			return ret;
		}
		void print(){	
			printf("(%d, %d) to (%d, %d)\n", sx, sy, ex, ey);
		}
	} tmpData, maxpos;
	vector<judgeData> jdata;

	int (*grid)[N];
	int fcnt, mcnt, scnt, maxs;
	int flim, mlim, slim, vlim;
	int sx, sy, ex, ey;
	bool suc;

	inline int abs(int x){return x>=0? x:-x;}
	void print(){ 
		printf("(%d, %d) to (%d, %d)\n", sx, sy, ex, ey);
		for (int i=0; i<N; i++){
			for (int j=0; j<N; j++){
				printf("%d", grid[i][j]);
			}
			putchar('\n');
		}
		printf("Maxpos: ");
		maxpos.print();
	}

	void judge(result WA){
		freopen(PROC".out", "w", stdout);
//		print();
		cout << "$Maximum number of steps: " << maxs << endl;
		if (WA == CORRECT)
			cout << "$Correct";
		else
			cout << "$WA[" << WA << "]";
		fclose(stdout);
		exit(0);
	}

	int position(int x, int y){
		if (x < 0 || x >= N || y < 0 || y >= N)
			return -1;
		if (x==0 || x==N-1 || y==0 || y==N-1)
			return 0;
		return 1;
	}

	void setFlag(int x, int y, int val){
		fcnt++;
		if (fcnt > flim)
			judge(TOO_MANY_FLAGS);
		if (position(x, y) == -1)
			judge(SETFLAG_INVALID_ARGUMENT);
		if (val < 0 || val > vlim)
			judge(SETFLAG_OUT);
		grid[x][y] = val;
	}

	std::vector<int> move(int dir, int count){
		if (count >= N || count <= 0)
			judge(MOVE_TOO_FAR);
		if (dir < 0 || dir >= 4)
			judge(MOVE_INVALID_ARGUMENT);
		sx += dx[dir]*count;
		sy += dy[dir]*count;
		if (position(sx, sy) <= 0)
			judge(MOVE_OUT);
		mcnt += count;
		scnt++;
		if (mcnt > mlim)
			judge(MOVE_NOT_OPTIMAL);
		if (scnt > slim)
			judge(TOO_MANY_STEPS);
		vector<int> ret;
		if (sx == ex && sy == ey){
			suc = true;
			return ret;
		}
		for (int i=0; i<=4; i++){
			int nx = sx+dx[i];
			int ny = sy+dy[i];
			ret.push_back(grid[nx][ny]);
		}
		return ret;
	}

	void run(){
		freopen("board.in", "r", stdin);
		srand(990306);
		int caseno;
		cin >> slim >> vlim >> caseno;
		slim = 2*N;
		while (tmpData.read())
			jdata.push_back(tmpData);
		fclose(stdin);
		
		//shiro
		shiro::initShiro(caseno);
		mlim = 0;
		flim = N*N;
		for (auto &e: jdata){
			fcnt = 0;
			sx = e.sx;
			sy = e.sy;
			ex = e.ex;
			ey = e.ey;
			grid = e.save;
			shiro::shiro(ex, ey);
		}
		random_shuffle(jdata.begin(), jdata.end());

		//sora
		sora::initSora(caseno);
		flim = 0;
		vector<int> ret;
		for (auto &e: jdata){
			mcnt = scnt = 0;
			sx = e.sx;
			sy = e.sy;
			ex = e.ex;
			ey = e.ey;
			grid = e.save;
			suc = false;
			mlim = abs(sx-ex) + abs(sy-ey);
			ret.clear();
			for (int i=0; i<=4; i++){
				int nx = sx+dx[i];
				int ny = sy+dy[i];
				ret.push_back(grid[nx][ny]);
			}
			sora::sora(e.sx, e.sy, ret);
			if (!suc)
				judge(UNEXPECTED_TERMINATION);
			if (scnt > maxs){
				maxpos = e;
				maxs = scnt;
			}
		}
		judge(CORRECT);
	}
}

void setFlag(int x, int y, int val){
	grader::setFlag(x, y, val);
}

vector<int> move(int dir, int count){
	return grader::move(dir, count);
}

int main(){
	grader::run();
	return 0;
}
