#ifndef GRADER_H
#define GRADER_H

#include <vector>
const int N = 128;
const int dx[] = {1, -1, 0, 0, 0};
const int dy[] = {0, 0, 1, -1, 0};
void setFlag(int x, int y, int val);
std::vector<int> move(int dir, int count);

#endif
