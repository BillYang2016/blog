#ifndef LEMON_JUDGE
#include "grader.h"
#endif
using namespace std;
//Do not declare any global variables
namespace sora{
	//declare your variables here

	//implement these functions
	void initSora(int caseno){}

	void sora(int x, int y, vector<int> v){
		while (move(2, 1).size());
	}
}