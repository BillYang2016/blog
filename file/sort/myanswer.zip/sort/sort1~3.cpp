#include<algorithm>
#include<iostream>
#include<iomanip>
#include<cstring>
#include<cstdlib>
#include<climits>
#include<vector>
#include<cstdio>
#include<cmath>
#include<queue>
using namespace std;

inline const int Get_Int() {
	int num=0,bj=1;
	char x=getchar();
	while(x<'0'||x>'9') {
		if(x=='-')bj=-1;
		x=getchar();
	}
	while(x>='0'&&x<='9') {
		num=num*10+x-'0';
		x=getchar();
	}
	return num*bj;
}

int n,m,p[55][55],pos[55],Now[55],a[55],ans[55];

void Move_Forward(int id) {
	int tmp=pos[p[id][p[id][0]]];
	for(int j=p[id][0]; j>=2; j--)pos[p[id][j]]=pos[p[id][j-1]];
	pos[p[id][1]]=tmp;
	for(int j=1; j<=n; j++)Now[pos[j]]=j;
}

void Move_Back(int id) {
	int tmp=pos[p[id][1]];
	for(int j=1; j<p[id][0]; j++)pos[p[id][j]]=pos[p[id][j+1]];
	pos[p[id][p[id][0]]]=tmp;
	for(int j=1; j<=n; j++)Now[pos[j]]=j;
}

void Dfs(int depth) {
	if(depth>9)return;
	bool bj=1;
	for(int i=1; i<=n; i++)
		if(pos[i]!=i) {
			bj=0;
			break;
		}
	if(bj) {
		printf("%d\n",depth-1);
		for(int i=1; i<depth; i++)printf("%d\n",ans[i]);
		exit(0);
	}
	for(int i=1; i<=m; i++) {
		Move_Forward(i);
		ans[depth]=i;
		Dfs(depth+1);
		Move_Back(i);
	}
}

int main() {
	n=Get_Int();
	m=Get_Int();
	for(int i=1; i<=n; i++) {
		Now[i]=a[i]=Get_Int();
		pos[a[i]]=i;
	}
	for(int i=1; i<=m; i++) {
		p[i][0]=Get_Int();
		for(int j=1; j<=p[i][0]; j++)p[i][j]=Get_Int();
	}
	Dfs(1);
	return 0;
} 

