#include<algorithm>
#include<iostream>
#include<iomanip>
#include<cstring>
#include<cstdlib>
#include<climits>
#include<vector>
#include<cstdio>
#include<cmath>
#include<queue>
using namespace std;

inline const int Get_Int() {
	int num=0,bj=1;
	char x=getchar();
	while(x<'0'||x>'9') {
		if(x=='-')bj=-1;
		x=getchar();
	}
	while(x>='0'&&x<='9') {
		num=num*10+x-'0';
		x=getchar();
	}
	return num*bj;
}

const int maxn=1005;

int n,m,map[maxn][maxn],Dfn[maxn],Lowlink[maxn],Instack[maxn],Stack[maxn],step=0,top=0,SCC=0;
vector<int>edges[maxn],Circle[maxn];

void AddEdge(int x,int y) {
	edges[x].push_back(y);
}

void Tarjan(int Now) {
	Dfn[Now]=Lowlink[Now]=++step;
	Stack[++top]=Now;
	Instack[Now]=1;
	for(int Next:edges[Now]) {
		if(!Dfn[Next]) {
			Tarjan(Next);
			Lowlink[Now]=min(Lowlink[Now],Lowlink[Next]);
		} else if(Instack[Now])Lowlink[Now]=min(Lowlink[Now],Dfn[Next]);
	}
	if(Dfn[Now]==Lowlink[Now]) {
		int y;
		SCC++;
		do {
			y=Stack[top--];
			Circle[SCC].push_back(y);
			Instack[y]=0;
		} while(y!=Now);
		reverse(Circle[SCC].begin(),Circle[SCC].end());
	} 
}

int main() {
	freopen("sort5.in","r",stdin);
	freopen("sort5.out","w",stdout);
	n=Get_Int();
	m=Get_Int();
	for(int i=1; i<=n; i++) {
		int x=Get_Int();
		AddEdge(i,x);
	}
	for(int i=1; i<=n; i++)
		if(!Dfn[i])Tarjan(i);
	for(int i=1; i<=m; i++) {
		Get_Int();
		int x=Get_Int(),y=Get_Int();
		map[x][y]=map[y][x]=i;
	}
	printf("%d\n",n-SCC);
	for(int i=1; i<=SCC; i++) {
		int size=Circle[i].size();
		for(int j=0; j<=size-2; j++)printf("%d\n",map[Circle[i][j]][Circle[i][j+1]]);
	}
	return 0;
} 

