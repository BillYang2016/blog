#include<algorithm>
#include<iostream>
#include<iomanip>
#include<cstring>
#include<cstdlib>
#include<climits>
#include<vector>
#include<cstdio>
#include<cmath>
#include<queue>
using namespace std;

inline const int Get_Int() {
	int num=0,bj=1;
	char x=getchar();
	while(x<'0'||x>'9') {
		if(x=='-')bj=-1;
		x=getchar();
	}
	while(x>='0'&&x<='9') {
		num=num*10+x-'0';
		x=getchar();
	}
	return num*bj;
}

const int maxn=40005;

int n,m,a[maxn],Pos[maxn],Depth[maxn],Up_Move[maxn];
vector<int> ans;

#define ls num<<1
#define rs num<<1|1
#define fa num>>1

void Cal(int pos) {
	if(a[pos]==pos)return;
	int num=a[pos],son1=num,son2=pos;
	if(Depth[son1]<Depth[son2])swap(son1,son2);
	static int path[maxn];
	fill(path+1,path+n+1,0);
	while(Depth[son1]!=Depth[son2]) {
		path[son1]=1;
		son1>>=1;
	}
	while(son1!=son2) {
		path[son1]=path[son2]=1;
		son1>>=1;
		son2>>=1;
	}
	path[son1]=1;
	while(num!=pos) {
		path[num]=0;
		int next=0;
		if(path[fa])next=fa;
		else if(path[ls])next=ls;
		else next=rs;
		if(next>num)ans.push_back(Up_Move[next]); //������
		else ans.push_back(Up_Move[num]); //������ 
		swap(Pos[num],Pos[next]);
		a[Pos[num]]=num,a[Pos[next]]=next;
		num=next;
	}
}

int main() {
	freopen("sort10.in","r",stdin);
	freopen("sort10.out","w",stdout);
	n=Get_Int();
	m=Get_Int();
	for(int i=1; i<=n; i++)Depth[i]=Depth[i>>1]+1;
	for(int i=1; i<=n; i++) {
		a[i]=Get_Int();
		Pos[a[i]]=i;
	}
	for(int i=1; i<=m; i++) {
		Get_Int();
		Up_Move[Get_Int()]=i;
		Get_Int();
	}
	for(int i=n; i>=1; i--)Cal(i);
	printf("%d\n",ans.size());
	for(int x:ans)printf("%d\n",x);
	return 0;
} 

