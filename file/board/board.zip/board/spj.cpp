#include <cstdio>
#include <iostream>
#include <cstring>
#include <algorithm>
#include <cmath>
#include <fstream>
#include <cstdlib>
#include <string>
using namespace std;
ifstream fin, fout, fans;
ofstream flog, fscore;
double full;
void judge(double score, string info){
	flog << info;
	fscore << score;
	exit(0);
}

template<class T>
void read(ifstream &in, T &var){
	in >> var;
	if (in.fail())
		judge(0, "Invalid output!");
}

int main(int argc, char** argv){
	fin.open(argv[1]);
	fout.open(argv[2]);
	fans.open(argv[3]);
	full = atof(argv[4]);
	fscore.open(argv[5]);
	flog.open(argv[6]);
	if (flog.fail()||fscore.fail()){
		cerr << "Cannot open output file!" << endl;
		return 0;
	}
	if (fin.fail()||fout.fail()||fans.fail()){
		judge(0, "Cannot open input file!");
	}
	int V, U;
	read(fin, V);
	string s;
	while (getline(fout, s)){
		if (s.size()==0 || s[0]!='$') continue;
		if (s.substr(0, 3) == "$WA"){
			judge(0, s.substr(1));
		} else {
			for (unsigned int i=0; i<s.size(); i++){
				if (s[i] == ':'){
					U = stoi(s.substr(i+2));
					break;
				}
			}
		}
	}
	double score = full*min(U, V)/U;
	judge(score, "Correct: "+to_string(U)+" steps.");
	return 0;
}
