#include<algorithm>
#include<iostream>
#include<iomanip>
#include<cstring>
#include<cstdlib>
#include<climits>
#include<vector>
#include<cstdio>
#include<cmath>
#include<queue>
using namespace std;

inline const int Get_Int() {
	int num=0,bj=1;
	char x=getchar();
	while(x<'0'||x>'9') {
		if(x=='-')bj=-1;
		x=getchar();
	}
	while(x>='0'&&x<='9') {
		num=num*10+x-'0';
		x=getchar();
	}
	return num*bj;
}

int n,m,p[505],pos[505],id[505];
vector<int> ans;

int main() {
	freopen("sort4.in","r",stdin);
	freopen("sort4.out","w",stdout);
	n=Get_Int();
	m=Get_Int();
	for(int i=1; i<=n; i++) {
		p[i]=Get_Int();
		pos[p[i]]=i;
	}
	for(int i=1;i<=m;i++) {
		Get_Int();
		id[Get_Int()]=i;
		Get_Int();
	}
	for(int i=1; i<=n; i++)
		for(int j=p[i]-1; j>=i; j--) {
			ans.push_back(id[j]);
			swap(pos[j],pos[j+1]);
			p[pos[j]]=j;
			p[pos[j+1]]=j+1;
		}
	printf("%d\n",ans.size());
	for(int x:ans)printf("%d\n",x);
	return 0;
} 

